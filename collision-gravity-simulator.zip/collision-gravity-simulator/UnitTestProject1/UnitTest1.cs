﻿using System;
using GameLogic;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace UnitTestProject1
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void Vec2HashTest()
        {

            Vec2 v1 = new Vec2(1,1);
            Console.WriteLine(v1.GetHashCode());
            Vec2 v2 = new Vec2(1,1);
            Console.WriteLine(v2.GetHashCode());
            Vec2 v3 = new Vec2(2, 2);
            Console.WriteLine(v3.GetHashCode());

            Assert.AreEqual(v1, v2);
            Assert.AreNotEqual(v1, v3);
            Assert.AreNotEqual(v2, v3);

            Assert.AreEqual(v1.GetHashCode(), v2.GetHashCode());
            Assert.AreNotEqual(v1.GetHashCode(), v3.GetHashCode());
            Assert.AreNotEqual(v2.GetHashCode(), v3.GetHashCode());

        }

        [TestMethod]
        public void BallVHashTest()
        {
            BallV b1 = new BallV(1, 1, 0, 0, 1);
            Console.WriteLine(b1.GetHashCode());
            BallV b2 = new BallV(1, 1, 0, 0, 1);
            Console.WriteLine(b2.GetHashCode());
            BallV b3 = new BallV(1, 0, 0, 0, 1);
            Console.WriteLine(b3.GetHashCode());
            BallV b4 = new BallV(1, 1, 0, 1, 1);
            Console.WriteLine(b4.GetHashCode());

            Assert.AreEqual(b1, b2);
            Assert.AreEqual(b1.GetHashCode(), b2.GetHashCode());

            Assert.AreNotEqual(b1, b3);
            Assert.AreNotEqual(b1.GetHashCode(), b3.GetHashCode());

            Assert.AreNotEqual(b1, b4);
            Assert.AreNotEqual(b1.GetHashCode(), b4.GetHashCode());
        }
    }
}
